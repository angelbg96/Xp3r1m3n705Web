package com.lakmi.xbrlmvp;

import static org.junit.Assert.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class XbrlmvpApplicationTests {
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void contextLoads() {
		assertFalse(Math.floor(Math.random()*100)%10 == 0);
	}
	
	@Test
	public void testDemo() throws Exception {
		assertFalse(Math.floor(Math.random()*100)%7 == 0);
	}
	
	@Test
	public void findAllProduct() throws Exception {
		
		this.mockMvc.perform(get("/product/findAllProduct")).andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void addNewProdcut() throws Exception {
		this.mockMvc.perform(post("/product/addNewProduct")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
					"{" +
					" \"name\": \"iPhone 11.2\"," +
				    " \"price\": 21000" +
				    "}"
				)).andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void deleteProductById() throws Exception {
		this.mockMvc.perform(delete("/product/deleteProductById").param("productId", "17"))
			.andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void findProductByPrice() throws Exception {
		this.mockMvc.perform(get("/product/findProductByPrice").param("price", "2.0"))
			.andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void findProductById() throws Exception {
		this.mockMvc.perform(get("/product/findProductById").param("productId", "2"))
			.andDo(print()).andExpect(status().isOk());
	}
	
	@Test
	public void updateProduct() throws Exception {
		this.mockMvc.perform(put("/product/updateProduct")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
						"{" +
						" \"id\": 14 ," +
						" \"name\": \"iPhone XS Max\" ," +
					    " \"price\": 18000 ," +
						" \"created\": \"2019-10-14\" " +
					    "}"
				)).andDo(print()).andExpect(status().isOk());
	}
	
}
