package com.lakmi.xbrlmvp.business.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lakmi.xbrlmvp.business.ProductBusiness;
import com.lakmi.xbrlmvp.dto.request.ProductRequestEntityDTO;
import com.lakmi.xbrlmvp.entity.Product;
import com.lakmi.xbrlmvp.exception.EmptyProductListException;
import com.lakmi.xbrlmvp.exception.ProductNotFoundException;
import com.lakmi.xbrlmvp.repository.ProductRepository;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProductBusinessImpl implements ProductBusiness {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public Product addNewProduct(ProductRequestEntityDTO request) {
		Product product = Product.builder()
				.name(request.getName())
				.price(request.getPrice())
				.created(new Date())
				.build();
        log.info("Creando nuevo producto...");
        
        try {
            product = productRepository.save(product);
        }
        catch(Exception e){
            product = null;
            log.info("Error al guardar el producto",e);
        }
        return product;
	}

	@Override
	public Product findProductById(Integer productId) {
		log.info("Buscando producto por su Id...");
		Product product = productRepository.findProductById( productId );
		if( product == null )
            throw new ProductNotFoundException();
        return product;
	}

	@Override
	public Boolean deleteProductById(Integer productId) {
		Product product = findProductById( productId );
        if( product == null )
            throw new ProductNotFoundException();
		try {
            productRepository.deleteById( productId );
        }
        catch( Exception e ) {
            log.info("Error al eliminar product por id "+ productId, e);
            return false;
        }
        return true;
	}

	@Override
	public List<Product> findByPrice(Double price) {
		List<Product> list = productRepository.findByPrice( price );
		if(list.isEmpty())
			throw new EmptyProductListException();
        return list;
	}

	@Override
	public List<Product> findAllProduct() {
		List<Product> list = productRepository.findAll();
		if(list.isEmpty())
			throw new EmptyProductListException();
		return list;
	}

	@Override
	public Product updateProduct(ProductRequestEntityDTO request) {
			log.info("Actualizando producto...");
			Product product = Product.builder()
					.id(request.getId())
					.name(request.getName())
					.price(request.getPrice())
					.created(request.getCreated())
					.build();
			try {
	            product = productRepository.save(product);
	        }catch(Exception e){
	            product = null;
	            log.info("Error al guardar el producto",e);
	        }
		return product;
	}

}
