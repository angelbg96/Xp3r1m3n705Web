package com.lakmi.xbrlmvp.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lakmi.xbrlmvp.business.ProductBusiness;
import com.lakmi.xbrlmvp.dto.request.ProductRequestEntityDTO;
import com.lakmi.xbrlmvp.dto.response.ResponseDTO;
import com.lakmi.xbrlmvp.entity.Product;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ProductController {
	private static final String MSG_00 = "Respuesta exitosa";
	private static final String CODE_00 = "RSP_00";
	@Autowired
	private ProductBusiness productBusiness;
	
	@GetMapping("/product/demo")
	public Product demo() {
		log.info("Creando producto demo...");
		return Product.builder()
				.id(null)
				.name("iPhone")
				.price(2.5)
				.created(new Date())
				.build();
	}
	
	@PostMapping("/product/addNewProduct")
    public ResponseEntity<ResponseDTO> addNewProduct(@Valid @RequestBody ProductRequestEntityDTO request) {
        ResponseDTO response = null;
        Product product = productBusiness.addNewProduct(request);
        response = ResponseDTO.builder()
        		.code(CODE_00)
        		.message(MSG_00)
        		.response(product)
        		.build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
	
	@DeleteMapping("/product/deleteProductById")
    public ResponseEntity<ResponseDTO> deleteProductById( @RequestParam Integer productId ) {
        ResponseDTO response = null;
        Boolean res = productBusiness.deleteProductById( productId );
        if ( Boolean.TRUE.equals(res) ) {
            response = ResponseDTO.builder()
            		.code(CODE_00)
            		.message(MSG_00)
            		.response(res)
            		.build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@GetMapping("/product/findProductByPrice")
    public ResponseEntity<ResponseDTO> findByPrice( @RequestParam Double price ) {
        ResponseDTO response = null;
        List<Product> list = productBusiness.findByPrice( price );
        response = ResponseDTO.builder()
        		.code(CODE_00)
        		.message(MSG_00)
        		.response(list)
        		.build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
	
	@GetMapping("/product/findProductById")
    public ResponseEntity<ResponseDTO> findProductById( @RequestParam Integer productId  ) {
        ResponseDTO response = null;
        Product product = productBusiness.findProductById( productId );
        response = ResponseDTO.builder()
        		.code(CODE_00)
        		.message(MSG_00)
        		.response(product)
        		.build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
	
	@GetMapping("/product/findAllProduct")
    public ResponseEntity<ResponseDTO> findAllProduct() {
        ResponseDTO response = null;
        List<Product> list = productBusiness.findAllProduct();
        response = ResponseDTO.builder()
        		.code(CODE_00)
        		.message(MSG_00)
        		.response(list)
        		.build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
	
	@PutMapping("/product/updateProduct")
	public ResponseEntity<ResponseDTO> updateProduct(@Valid @RequestBody ProductRequestEntityDTO request) {
        ResponseDTO response = null;
        Product product = productBusiness.updateProduct(request);
        response = ResponseDTO.builder()
        		.code(CODE_00)
        		.message(MSG_00)
        		.response(product)
        		.build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
