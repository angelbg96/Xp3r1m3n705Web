package com.lakmi.xbrlmvp.dto.request;

import java.util.Date;

import lombok.Data;

@Data
public class ProductRequestEntityDTO {
	private Integer id;
	private String name;
    private Double price;
    private Date created;
    
}
