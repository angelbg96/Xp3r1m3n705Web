package com.lakmi.xbrlmvp.exception.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.lakmi.xbrlmvp.dto.response.ResponseDTO;
import com.lakmi.xbrlmvp.exception.EmptyProductListException;
import com.lakmi.xbrlmvp.exception.ProductNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class ProductExceptionController {
	@ExceptionHandler(value = ProductNotFoundException.class)
	public ResponseEntity<ResponseDTO> exception( ProductNotFoundException e ) {
		log.error( "Producto no encontrado" , e );
		String messageResponseError = "TrackingNumber no es valido";		
		
		return new ResponseEntity<>(
				ResponseDTO.builder()
					.code("RSP_01")
					.message("Error, producto no encontrado")
					.response( messageResponseError )
					.build()
				, HttpStatus.BAD_REQUEST);		
	}

	@ExceptionHandler(value = EmptyProductListException.class)
	public ResponseEntity<ResponseDTO> exception( EmptyProductListException e ) {
		String messageResponseError = "Listado de productos vacia";
		log.error( "Error empty product list" , e );

		return new ResponseEntity<>(
				ResponseDTO.builder()
					.code("RSP_01")
					.message("Error, listado de productos vacia")
					.response( messageResponseError )
					.build()
				, HttpStatus.NOT_FOUND);		
	}
}
