package com.lakmi.xbrlmvp.exception;

public class EmptyProductListException extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
