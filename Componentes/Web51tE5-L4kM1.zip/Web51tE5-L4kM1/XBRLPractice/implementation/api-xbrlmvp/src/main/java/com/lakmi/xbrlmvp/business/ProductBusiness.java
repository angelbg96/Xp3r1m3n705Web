package com.lakmi.xbrlmvp.business;

import java.util.List;
import com.lakmi.xbrlmvp.dto.request.ProductRequestEntityDTO;
import com.lakmi.xbrlmvp.entity.Product;

public interface ProductBusiness {
	public Product addNewProduct(ProductRequestEntityDTO request);
	public Product findProductById(Integer productId);
	public Boolean deleteProductById(Integer productId);
	public List<Product> findByPrice(Double price);
	public List<Product> findAllProduct();
	public Product updateProduct(ProductRequestEntityDTO request);
}
