# LakmiXBRLPractice

Conexión con MySQL
* IP: 167.71.86.162:3306
* username: lakmyxbrlusr
* password: A1_b9b09b6a3b
