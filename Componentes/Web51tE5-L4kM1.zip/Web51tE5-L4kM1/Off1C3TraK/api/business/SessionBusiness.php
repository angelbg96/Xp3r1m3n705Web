<?php

interface SessionBusiness {

   public function create( $sessionDTO );
   public function delete( $sessionDTO );
   
}
?>